import json
import boto3
import botocore.exceptions

def lambda_handler(event, context):
    # Access the properties in the request body
    ride_id = event['ride_id']
    driver_id = event['driver_id']
    status = event['status']
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('RideRequestsTable')

        # Acquire the lock for the ride request.
        lock_acquired = acquire_ride_request_lock(ride_id)
        print(lock_acquired)

        # If the lock is not acquired, raise an error.
        if not lock_acquired:
            return {
                "statusCode": 400,
                "body": "Ride request was already accepted by another driver"
            }

        # Update the status of the ride request within a transaction.
        try:
            response = table.update_item(
                Key={"ride_id": ride_id},
                UpdateExpression="SET #statusAttr = :newStatus, driver_id = :driverId",
                ConditionExpression="#statusAttr IN (:oldStatus1, :oldStatus2)",
                ExpressionAttributeNames={"#statusAttr": "status"},
                ExpressionAttributeValues={
                    ":newStatus": status,
                    ":oldStatus1": "Pending",
                    ":oldStatus2": "Rejected",
                    ":driverId": driver_id
                }
            )
        except botocore.exceptions.ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "ConditionalCheckFailedException":
                raise ValueError("Ride request was already accepted by another driver")
            else:
                raise


        # Release the lock for the ride request.
        release_ride_request_lock(ride_id)

    except botocore.exceptions.ClientError as e:
        error_message = e.response["Error"]["Message"]
        return {
            "statusCode": 500,
            "body": f"An error occurred: {error_message}"
        }
    except ValueError as e:
        return {
            "statusCode": 400,
            "body": str(e)
        }

    return {
        "statusCode": 200,
        "message": "Ride request accepted"
    }

def acquire_ride_request_lock(ride_request_id):
    """Acquires the lock for a ride request in DynamoDB.

    Args:
        ride_request_id: The ID of the ride request.

    Returns:
        True if the lock is acquired successfully, False otherwise.
    """

    table = boto3.resource("dynamodb").Table("RideRequestsLocksTable")
    try:
        response = table.update_item(
            Key={"ride_request_id": ride_request_id},
            UpdateExpression="SET #lockAttr = :newLock",
            ConditionExpression="attribute_not_exists(#lockAttr) OR #lockAttr = :oldLock",
            ExpressionAttributeNames={"#lockAttr": "lock"},
            ExpressionAttributeValues={":newLock": True, ":oldLock": False},
            ReturnValues="ALL_NEW"
        )
        lock_acquired = response["Attributes"]["lock"]
    except botocore.exceptions.ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code == "ConditionalCheckFailedException":
            lock_acquired = False
        else:
            raise

    return lock_acquired

def release_ride_request_lock(ride_request_id):
    """Releases the lock for a ride request in DynamoDB.

    Args:
        ride_request_id: The ID of the ride request.
    """
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('RideRequestsLocksTable')
    table.update_item(
        Key={"ride_request_id": ride_request_id},
        UpdateExpression="SET #lockAttr = :lock",
        ExpressionAttributeNames={"#lockAttr": "lock"},
        ExpressionAttributeValues={":lock": False},
    )