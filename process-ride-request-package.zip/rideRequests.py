import boto3
import json

def lambda_handler(event, context):
    try:
        # Get the ride request from the SQS message.
        sqs_message = event['Records'][0]['body']
        ride_request = json.loads(sqs_message)
        print('SQS Message received:')
        print(ride_request)
        
        # Perform business logic and driver assignment
        # Store the processed ride request in DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('RideRequestsTable')
        response = table.put_item(Item={'ride_id': ride_request['ride_id'], 'passenger_id': ride_request['passenger_id'], 'status': 'Pending'})
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            print("Ride request inserted successfully")
        else:
            print("Ride request insertion failed")
    
        # Publish a notification to the SNS topic
        sns = boto3.client('sns')
        response = sns.publish(TopicArn='arn:aws:sns:ap-southeast-1:921490761789:DriverNotificationsTopic', Message='New ride request!')
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            print("Message published successfully")
        else:
            print("Message publication failed")
        
        sqs = boto3.client('sqs')
        sqs.delete_message(QueueUrl=event['Records'][0]['queueUrl'], ReceiptHandle=sqs_message)
    
        return {
            'statusCode': 200,
            'body': json.dumps({'status':'success', 'message': 'Notification sent'})
        }
    except Exception as ex:
        print(str(ex))
        return {
            'statusCode': 500,
            'body': json.dumps({'status':'fa', 'message': 'Notification sent'})
        }